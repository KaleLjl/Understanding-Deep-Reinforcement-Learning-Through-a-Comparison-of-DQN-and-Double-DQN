import ray
from ray.rllib.algorithms.dqn import DQN
from ray.tune.registry import register_env
import gymnasium as gym
import numpy as np

# Ensure Ray is initialized
ray.init(ignore_reinit_error=True)

# Register the environment to match training configuration
env_name = "CartPole-v1"
register_env(env_name, lambda config: gym.make(env_name))

# Previous experiment's checkpoint path
checkpoint_path = "/path/to/checkpoint"

# Provide the trained model configuration
param_space = {

    "lr": ,
    "train_batch_size": ,
    "gamma": ,
    "replay_buffer_config": {
        "capacity": 
    },
    "model": {
        "fcnet_hiddens": [ , ],
        "fcnet_activation": "relu",
    },
    "env": env_name,
}

algorithm = DQN(config=param_space)
algorithm.restore(checkpoint_path)

# Create an environment instance
env = gym.make(env_name, render_mode="human")

# Initialize the environment and start demonstration
state = env.reset()
done = False
total_reward = 0
while not done:
    current_state = np.array(state[0], dtype=np.float32) if isinstance(state, tuple) else np.array(state, dtype=np.float32)
    action = algorithm.compute_single_action(current_state, explore=False)
    # Adjusting to the updated step method return values
    state, reward, done, truncated, _ = env.step(action)
    total_reward += reward
    env.render()  # Visualize the environment
    print(f"Total reward: {total_reward}")

# Close the environment and Ray
env.close()
ray.shutdown()
